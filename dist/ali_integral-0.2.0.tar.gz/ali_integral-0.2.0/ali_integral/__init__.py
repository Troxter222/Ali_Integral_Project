from .visualizer import plot_information_horizon

def run_simulation(target="SgrA*", save_plot=False):
    from .physics import get_mass, calculate_ali_integral
    
    mass = get_mass(target)
    print("--- Ali Integral Simulation v0.2.0 ---")
    print(f"Target: {target} (Mass: {mass:.2e} Solar Masses)")
    
    result_bits = calculate_ali_integral(mass) 
    
    print(f"Total Observable Information (OFI): {result_bits:.2e} bits")
    
    print("Generating Visualization...")
    plot_information_horizon(mass)
    
    if save_plot:
        print("Plot saved as 'ali_vision_result.png'")