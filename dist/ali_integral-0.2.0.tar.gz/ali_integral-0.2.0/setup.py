from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='ali_integral',
    version='0.2.0',
    description='A Python library for calculating Information Flux at the Cauchy Horizon',
    long_description=long_description,
    packages=find_packages(include=['ali_integral', 'ali_integral.*']),
    long_description_content_type="text/markdown",
    install_requires=[
        'numpy',
        'matplotlib',
        'scipy',
        'imageio'
    ],
)